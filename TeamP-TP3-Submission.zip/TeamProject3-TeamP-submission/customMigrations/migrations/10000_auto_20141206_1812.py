# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('customMigrations', '9998_custom_tags_priorities'),
        ('customMigrations', '9999_custom_20141206_1511'),
    ]

    operations = [
    ]
