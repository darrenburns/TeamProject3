from django.contrib import admin
from core.models import Project, UserProfile

admin.site.register(Project)
admin.site.register(UserProfile)