'use strict';

var $ = require('jquery');
require('../chat/static/chat/js');
require('../core/static/core/js');
require('bootstrap');
require('bootstrap-select');
require('react-datepicker');

// TODO: Temporarily disabled tooltips
//$(function () {
    //$("[danta-toggle='tooltip']").tooltip();
//});
